
DEFAULT_SLACK_WEBHOOK = 'https://hooks.slack.com/services/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'
