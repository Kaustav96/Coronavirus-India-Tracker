import os
import smtplib

EMAIL_ADDRESS = '1415016@kiit.ac.in'
EMAIL_PASSWORD = 'mqntilwxhmchhfas'


with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
    smtp.ehlo()  # identifies with mail server we are using
    smtp.starttls()  # encrypt our traffic
    smtp.ehlo()  # again run this to reidetify as encrypted connection

    smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
    subject = 'test'
    body = ' test'
    msg = f'Subject :{subject}\n\n{body}'

    smtp.sendmail(EMAIL_ADDRESS, 'kaustavbanerjee96@gmail.com', msg)

    #mqntilwxhmchhfas
