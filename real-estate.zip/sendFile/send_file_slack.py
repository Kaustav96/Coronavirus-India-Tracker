import requests

file_path = ''

with {'file1': open('joke.jfif', 'rb'), 'file2': open('', 'rb')} as f:
    payload = {"filename": file_path,
               "token": "xoxp-1004629925682-1005947718707-1010298318019-b59ee7277766e2c1bc0d0467350e1b75",
               "channels": "coronavirus"}
    requests.post("https://slack.com/api/files.upload", params=payload, files={'file': f})
