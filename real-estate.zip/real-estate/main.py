import pandas as pd
import numpy as np
from bs4 import BeautifulSoup
import requests

res = requests.get('https://www.worldometers.info/coronavirus/#countries').text
soup = BeautifulSoup(res, 'html.parser')
get_table = soup.find('table', id='main_table_countries_today')
get_table_data = get_table.tbody.find_all('tr')
dic = {}
# print(get_table_data[8])
for i in range(7, len(get_table_data)):
    try:
        key = get_table_data[i].find_all('a', href=True)[0].string
    except:
        key = get_table_data[i].find_all("td")[0].string

    values = [j.string for j in get_table_data[i].find_all('td')]
    dic[key] = values

df = pd.DataFrame(dic).iloc[1:, :].T.iloc[:,:8]
column_names = ['Total Cases','New cases', 'Total Deaths, New Deaths', 'Total Recovered',' Active','Serious Critical',
                'Total Cases/1M pop', 'Total Death/1M pop']
df.index_name = "country"
df.columns = column_names
print(df.head())
