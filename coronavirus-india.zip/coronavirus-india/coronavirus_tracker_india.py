import requests
from bs4 import BeautifulSoup
import json
import logging
import schedule
import time
from datetime import datetime
from slack_client import slacker

from tabulate import tabulate

SHORT_HEADERS = ['Sno', 'State', 'Total Confirmed Cases', 'Total Active Cases', 'Cured', 'Death']
HEADERS = ['Total Confirmed Cases', 'Total Active Cases', 'Cured/Discharged', ' Deaths', 'Migrated']
FORMAT = '[%(asctime)-15s] %(message)s'
NEW_FILE_NAME = 'corona_india_data.json'
# OLD_FILE_NAME = 'prev_corona_india_data.json'
logging.basicConfig(format=FORMAT, level=logging.DEBUG, filename='bot.log', filemode='a')
current_time = datetime.now().strftime('%d/%m/%Y %H:%M')


def save_json(x):
    data = []

    for i in range(len(x)):
        state_id, state_name, indian, active, cured, death = x[i][0], x[i][1], x[i][2], x[i][3], x[i][4], x[i][5]
        data.append({'Data': {'Sno': state_id, 'Name': state_name, 'Indian+Foreign': indian,
                              'Total Active Cases': active, 'Cured': cured, 'Death': death}})
    with open(NEW_FILE_NAME, 'w+') as f:
        if len(f.read()) == 0:
            # f.write(json.dumps(data))
            json.dump(x, f)
        else:
            # f.write(',\n' + json.dumps(x))
            json.dump(x, f)


def load():
    with open(NEW_FILE_NAME, 'r') as f:
        res = json.load(f)
    return res


try:
    def main_work():
        info = []
        res = requests.get('https://www.mohfw.gov.in/')
        soup = BeautifulSoup(res.text, 'html.parser')

        stats = []
        total_stats = []
        try:
            my_data_str = ""
            last_data_updated = ""
            total_cases = soup.find_all('strong')[6].get_text()
            total_cured = soup.find_all('strong')[7].get_text()
            total_death = soup.find_all('strong')[8].get_text()
            total_migr = soup.find_all('strong')[9].get_text()
            total_confirmed = int(total_cases) + int(total_cured) + int(total_death) + int(total_migr)
            total_stats.append([total_confirmed, total_cases, total_cured, total_death, total_migr])
            for date_update in soup.find_all('h2')[0].find_all('span'):
                last_data_updated += date_update.get_text()
            # print(last_data_updated)
            for tr in soup.find_all('tbody')[0].find_all('tr'):
                my_data_str += tr.get_text()
            my_data_str = my_data_str[1:]
            org_stateList = my_data_str.split("\n")
            new_stateList = []
            for item in org_stateList:
                if item != '':
                    new_stateList.append(item)
            name_state_list = []
            # current data
            sum_ind, sum_foreign, sum_cured, sum_death, total_ind, total_foreign, total_active, total_cured, total_death = 0, 0, 0, 0, 0, 0, 0, 0, 0
            sum_active = 0
            count_items = 0
            # for state in new_stateList[0:len(new_stateList) - 4]:
            #     # removed total_foreign
            #     # print(state[0:5])
            #     # print(state[0], state[1], state[2], state[3], state[4])
            #     # state_id = state[count_items]
            #     # count_items = count_items + 1
            #     # state_name = state[count_items]
            #     # count_items = count_items + 1
            #     # total_ind = state[count_items]
            #     # count_items = count_items +1
            #     # total_cured = state[count_items]
            #     # count_items += 1
            #     # total_death = state[count_items]
            #     # count_items += 1
            #     # print(count_items)
            #     # print(state_id, state_name, total_ind, total_cured, total_death)
            #     sum_ind += int(total_ind)
            #     # sum_foreign += int(total_foreign)
            #     sum_cured += int(total_cured)
            #     sum_death += int(total_death)
            #     # stats.append([state_id, state_name, total_ind, total_cured, total_death])
            # when foreign national col not available
            # print(len(new_stateList))
            if len(new_stateList) == 154:
                while count_items < (len(new_stateList) - 4):
                    state_id = new_stateList[count_items:count_items + 5][0]
                    state_name = new_stateList[count_items:count_items + 5][1]
                    name_state_list.append(state_name)
                    total_ind = new_stateList[count_items:count_items + 5][2]
                    total_cured = new_stateList[count_items:count_items + 5][3]
                    total_death = new_stateList[count_items:count_items + 5][4]
                    total_active = int(total_ind) - (int(total_cured) + int(total_death))
                    sum_ind += int(total_ind)
                    sum_cured += int(total_cured)
                    sum_death += int(total_death)
                    sum_active += int(total_active)
                    stats.append([state_id, state_name, total_ind, str(total_active), total_cured, total_death])
                    count_items += 5
                stats.append(['', 'Total Number of Confirmed Cases in India', sum_ind, sum_active, sum_cured, sum_death])
                name_state_list.append('Total Number of Confirmed Cases in India')
                # save_json(stats)
                past_data = load()
            else:
                while count_items < (len(new_stateList) - 5):
                    state_id = new_stateList[count_items:count_items + 5][0]
                    state_name = new_stateList[count_items:count_items + 5][1]
                    name_state_list.append(state_name)
                    total_ind = new_stateList[count_items:count_items + 5][2]
                    total_cured = new_stateList[count_items:count_items + 5][3]
                    total_death = new_stateList[count_items:count_items + 5][4]
                    total_active = int(total_ind) - (int(total_cured) + int(total_death))
                    sum_ind += int(total_ind)
                    sum_cured += int(total_cured)
                    sum_death += int(total_death)
                    sum_active += int(total_active)
                    stats.append([state_id, state_name, total_ind, str(total_active), total_cured, total_death])
                    count_items += 5
                stats.append(['', 'Total Number of Confirmed Cases in India', sum_ind, sum_active, sum_cured, sum_death])
                name_state_list.append('Total Number of Confirmed Cases in India')
                # save_json(stats)
                past_data = load()
            # past data
            count_past, x, count_state = 0, 0, 0
            cur_states = [(x[1]) for x in stats[0:len(stats)]]
            past_state = [(x[1]) for x in past_data[0:len(past_data)]]
            # print(len(past_data),len(stats))
            # print(past_data)
            # print('Current states - ', sorted(cur_states))
            # print('Past States - ', sorted(past_state))
            # orig_stats = stats
            # stats.sort(key=lambda stats: stats[1])
            # 1st way

            # check if new state has been added or not else compare previous values with current value
            for state in cur_states:
                if state not in past_state:
                    cur_ind, cur_active, cur_cur, cur_death = stats[count_state][2], stats[count_state][3], \
                                                              stats[count_state][4], stats[count_state][5]
                    cur_str = 'Total->' + str(cur_ind) + ', Active->' + str(cur_active) + ', Cured->' + str(cur_cur) + \
                              ', Death->' + str(cur_death)
                    # print(f'New state - {state} got corona virus.{[cur_str]}')
                    info.append(f'NEW STATE - {state} got corona virus.{[cur_str]}')
                    count_state = count_state + 1
                else:
                    past_ind, past_active, past_cur, past_death = past_data[count_past][2], past_data[count_past][3], \
                                                                  past_data[count_past][4], past_data[count_past][5]
                    cur_ind, cur_active, cur_cur, cur_death = stats[count_state][2], stats[count_state][3], \
                                                              stats[count_state][4], stats[count_state][5]
                    past_str, cur_str = '', ''
                    if past_ind != cur_ind:
                        past_str += 'Total->' + str(past_ind) + ','
                        cur_str += 'Total->' + str(cur_ind) + ','
                    if past_active != cur_active:
                        past_str += 'Active->' + str(past_active) + ','
                        cur_str += 'Active->' + str(cur_active) + ','
                    if past_cur != cur_cur:
                        past_str += 'Cured->' + str(past_cur) + ','
                        cur_str += 'Cured->' + str(cur_cur) + ','
                    if past_death != cur_death:
                        past_str += 'Death->' + str(past_death)
                        cur_str += 'Death->' + str(cur_death)
                    if len(past_str) > 0 and len(cur_str) > 0:
                        # print(f'Change for {state}: [{past_str}]->[{cur_str}]')
                        info.append(f'Change for {state}: [{past_str}]->[{cur_str}]')
                    count_past = count_past + 1
                    count_state = count_state + 1
            # time being commented
            # for item in past_data:
            #     # cur_states.__contains__(item['Data']['Name']) and past_state.__contains__(item['Data']['Name']):
            #     # any([item['Data']['Name'] in i for i in cur_states]):
            #     if item[1] in cur_states and item[1] in past_state:
            #         past_ind, past_active, past_cur, past_death = item[2], item[3], item[4], item[5]
            #         # past_ind, past_active, past_cur, past_death = item['Data']['Indian+Foreign'], item['Data'][
            #         #     'Total Active Cases'], item['Data']['Cured'], item['Data']['Death']
            #         cur_ind, cur_active, cur_cur, cur_death = stats[count][2], stats[count][3], stats[count][4], \
            #                                                   stats[count][5]
            #         state_name = item[1]
            #         past_str, cur_str = '', ''
            #         if past_ind != cur_ind:
            #             past_str += 'Total->' + str(past_ind) + ','
            #             cur_str += 'Total->' + str(cur_ind) + ','
            #         if past_active != cur_active:
            #             past_str += 'Active->' + str(past_active) + ','
            #             cur_str += 'Active->' + str(cur_active) + ','
            #         if past_cur != cur_cur:
            #             past_str += 'Cured->' + str(past_cur) + ','
            #             cur_str += 'Cured->' + str(cur_cur) + ','
            #         if past_death != cur_death:
            #             past_str += 'Death->' + str(past_death)
            #             cur_str += 'Death->' + str(cur_death)
            #         if len(past_str) > 0 and len(cur_str) > 0:
            #             print(f'Change for {state_name}: [{past_str}]->[{cur_str}]')
            #             info.append(f'Change for {state_name}: [{past_str}]->[{cur_str}]')
            #         count = count + 1
            #     else:
            #         count = count + 1
            #
            #         name = item[1]
            #         # cur_ind, cur_active, cur_cur, cur_death = stats[count][2], stats[count][3], stats[count][4], \
            #         #                                           stats[count][5]
            #         # cur_str += 'Total->' + str(cur_ind) + ','
            #         # cur_str += 'Active->' + str(cur_active) + ','
            #         # cur_str += 'Cured->' + str(cur_cur) + ','
            #         # cur_str += 'Death->' + str(cur_death)
            #         print(f'New state {name} has been added.')
            #         # info.append(f'New state {name} has been added.[{cur_str}]')
            save_json(stats)  # stats.sort(key=lambda stats: stats[1])
            table = tabulate(stats, headers=SHORT_HEADERS, tablefmt='simple')
            table1 = tabulate(total_stats, headers=HEADERS, tablefmt='simple')
            # print(orig_stats)
            events_info = ''
            for event in info:
                logging.warning(event)
                events_info += '\n - ' + event.replace("'", "")
            now = datetime.now()
            dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
            print('Sent corona-virus update to the Slack App - ', dt_string)
            slack_text = f'Please find CoronaVirus Summary for India below:\n{last_data_updated}\n{events_info}\n```{table1}\n```'
            slacker()(slack_text)
            slack_text = f'```{table}```\n Stay home Stay Safe!!'
            slacker()(slack_text)
        except Exception as err:
            slacker()(f'Exception occurred: [{err}]')
            print(f'Exception occurred -> {err}')


    main_work()
except Exception as e:
    slacker()(f'Exception occurred: [{e}]')
    print(f'Exception occurred - {e}')

schedule.every().day.at("12:30").do(main_work)
schedule.every().day.at("20:30").do(main_work)
# schedule.every().day.at("21:00").do(main_work)

while True:
    # Checks whether a scheduled task
    # is pending to run or not
    # print("Current time ran job at - ",time.time())
    schedule.run_pending()
    time.sleep(1)
